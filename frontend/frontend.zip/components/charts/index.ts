// components/charts/index.ts
export { default as BarrasPorResponsavel } from "./BarrasPorResponsavel"
export { default as SankeyAreaLocalidade } from "./SankeyAreaLocalidade"
export { default as SunburstImpUrg } from "./SunburstImpUrg"
export { default as NightingaleQuadrante } from "./NightingaleQuadrante"