(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_globals_71f961d1.css",
  "static/chunks/node_modules_23da41e2._.js",
  "static/chunks/_9a28cce7._.js"
],
    source: "dynamic"
});
