(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/axios.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
const baseURL = (("TURBOPACK compile-time value", "http://127.0.0.1:8000/api") || "http://127.0.0.1:8000/api").replace(/\/+$/, "");
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL,
    headers: {
        "Content-Type": "application/json"
    }
});
/** Adiciona Authorization: Bearer <access> em toda request */ api.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem("voltlink_access");
        if (token) {
            config.headers = config.headers || {};
            config.headers.Authorization = "Bearer ".concat(token);
        }
    }
    return config;
});
/** Refresh automático do access quando tomar 401 */ let refreshing = false;
let waiters = [];
function notifyAll(newToken) {
    waiters.forEach((cb)=>cb(newToken));
    waiters = [];
}
api.interceptors.response.use((r)=>r, async (error)=>{
    var _error_response;
    const status = (_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.status;
    const original = error.config;
    if (status === 401 && !(original === null || original === void 0 ? void 0 : original._retry)) {
        original._retry = true;
        if (refreshing) {
            return new Promise((resolve)=>{
                waiters.push((token)=>{
                    original.headers = original.headers || {};
                    original.headers.Authorization = "Bearer ".concat(token);
                    resolve(api(original));
                });
            });
        }
        refreshing = true;
        try {
            var _this;
            const refresh = localStorage.getItem("voltlink_refresh");
            if (!refresh) throw new Error("no-refresh");
            const resp = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post("".concat(baseURL, "/token/refresh/"), {
                refresh
            }, {
                headers: {
                    "Content-Type": "application/json"
                }
            });
            const newAccess = (_this = resp.data) === null || _this === void 0 ? void 0 : _this.access;
            if (!newAccess) throw new Error("no-access");
            localStorage.setItem("voltlink_access", newAccess);
            notifyAll(newAccess);
            original.headers = original.headers || {};
            original.headers.Authorization = "Bearer ".concat(newAccess);
            return api(original);
        } catch (e) {
            localStorage.removeItem("voltlink_access");
            localStorage.removeItem("voltlink_refresh");
            if ("TURBOPACK compile-time truthy", 1) window.location.href = "/login";
            throw error;
        } finally{
            refreshing = false;
        }
    }
    throw error;
});
const __TURBOPACK__default__export__ = api;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useAtividadesAll.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/hooks/useAtividadesAll.ts
__turbopack_context__.s([
    "useAtividadesAll",
    ()=>useAtividadesAll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$axios$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/axios.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function useAtividadesAll() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "atividades-all"
        ],
        queryFn: {
            "useAtividadesAll.useQuery": async ()=>{
                var _r_data;
                const r = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$axios$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get("/atividades/", {
                    params: {
                        page_size: 1000
                    }
                });
                var _r_data_results;
                return (_r_data_results = (_r_data = r.data) === null || _r_data === void 0 ? void 0 : _r_data.results) !== null && _r_data_results !== void 0 ? _r_data_results : [];
            }
        }["useAtividadesAll.useQuery"]
    });
}
_s(useAtividadesAll, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/charts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/utils/charts.ts
__turbopack_context__.s([
    "groupByKey",
    ()=>groupByKey,
    "radialDataFromGroup",
    ()=>radialDataFromGroup
]);
function groupByKey(rows, key) {
    return rows.reduce((acc, row)=>{
        var _row_key;
        const k = String((_row_key = row[key]) !== null && _row_key !== void 0 ? _row_key : "");
        acc[k] = acc[k] || [];
        acc[k].push(row);
        return acc;
    }, {});
}
function radialDataFromGroup(groups) {
    return Object.entries(groups).map((param)=>{
        let [name, items] = param;
        return {
            name,
            value: items.length,
            items
        };
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/charts/badges.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// components/badges.tsx
__turbopack_context__.s([
    "levelBadge",
    ()=>levelBadge,
    "quadranteBadge",
    ()=>quadranteBadge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function levelBadge(level) {
    const base = "inline-flex items-center rounded px-2 py-0.5 text-xs font-medium text-white";
    if (level === "Alta") return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "".concat(base, " bg-rose-600"),
        children: "Alta"
    }, void 0, false, {
        fileName: "[project]/components/charts/badges.tsx",
        lineNumber: 7,
        columnNumber: 32
    }, this);
    if (level === "Média") return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "".concat(base, " bg-amber-500"),
        children: "Média"
    }, void 0, false, {
        fileName: "[project]/components/charts/badges.tsx",
        lineNumber: 8,
        columnNumber: 33
    }, this);
    if (level === "Baixa") return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "".concat(base, " bg-sky-600"),
        children: "Baixa"
    }, void 0, false, {
        fileName: "[project]/components/charts/badges.tsx",
        lineNumber: 9,
        columnNumber: 33
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "".concat(base, " bg-slate-400"),
        children: level !== null && level !== void 0 ? level : "-"
    }, void 0, false, {
        fileName: "[project]/components/charts/badges.tsx",
        lineNumber: 10,
        columnNumber: 10
    }, this);
}
function quadranteBadge(q) {
    const base = "inline-flex items-center rounded px-2 py-0.5 text-xs font-medium text-white";
    switch(q){
        case "Q1":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "".concat(base, " bg-rose-600"),
                children: "Q1"
            }, void 0, false, {
                fileName: "[project]/components/charts/badges.tsx",
                lineNumber: 17,
                columnNumber: 23
            }, this);
        case "Q2":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "".concat(base, " bg-amber-500"),
                children: "Q2"
            }, void 0, false, {
                fileName: "[project]/components/charts/badges.tsx",
                lineNumber: 18,
                columnNumber: 23
            }, this);
        case "Q3":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "".concat(base, " bg-sky-600"),
                children: "Q3"
            }, void 0, false, {
                fileName: "[project]/components/charts/badges.tsx",
                lineNumber: 19,
                columnNumber: 23
            }, this);
        case "Q4":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "".concat(base, " bg-cyan-600"),
                children: "Q4"
            }, void 0, false, {
                fileName: "[project]/components/charts/badges.tsx",
                lineNumber: 20,
                columnNumber: 23
            }, this);
        default:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "".concat(base, " bg-slate-400"),
                children: q !== null && q !== void 0 ? q : "-"
            }, void 0, false, {
                fileName: "[project]/components/charts/badges.tsx",
                lineNumber: 21,
                columnNumber: 23
            }, this);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/charts/Nightingale.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// components/charts/Nightingale.tsx
__turbopack_context__.s([
    "default",
    ()=>Nightingale
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/component/ResponsiveContainer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$RadialBarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/chart/RadialBarChart.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$RadialBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/polar/RadialBar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$PolarAngleAxis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/polar/PolarAngleAxis.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/component/Tooltip.js [app-client] (ecmascript)");
"use client";
;
;
function Nightingale(param) {
    let { title, data } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "card-glass h-full p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "section-header mb-2 font-medium",
                children: title
            }, void 0, false, {
                fileName: "[project]/components/charts/Nightingale.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResponsiveContainer"], {
                width: "100%",
                height: "88%",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$RadialBarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadialBarChart"], {
                    innerRadius: "20%",
                    outerRadius: "100%",
                    data: data,
                    startAngle: 90,
                    endAngle: -270,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$PolarAngleAxis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PolarAngleAxis"], {
                            type: "number",
                            domain: [
                                0,
                                Math.max(1, ...data.map((d)=>d.value))
                            ],
                            tick: false
                        }, void 0, false, {
                            fileName: "[project]/components/charts/Nightingale.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$RadialBar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadialBar"], {
                            background: true,
                            dataKey: "value",
                            label: {
                                position: "insideStart",
                                fill: "#fff",
                                fontSize: 11
                            },
                            fill: "#8884d8"
                        }, void 0, false, {
                            fileName: "[project]/components/charts/Nightingale.tsx",
                            lineNumber: 33,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tooltip"], {
                            content: (props)=>{
                                var _props_payload_, _props_payload, _p_items;
                                const p = props === null || props === void 0 ? void 0 : (_props_payload = props.payload) === null || _props_payload === void 0 ? void 0 : (_props_payload_ = _props_payload[0]) === null || _props_payload_ === void 0 ? void 0 : _props_payload_.payload;
                                if (!p) return null;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "card-glass p-2 text-xs",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium mb-1",
                                            children: [
                                                p.name,
                                                ": ",
                                                p.value
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/charts/Nightingale.tsx",
                                            lineNumber: 45,
                                            columnNumber: 19
                                        }, void 0),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "max-w-[260px] list-disc pl-4",
                                            children: (_p_items = p.items) === null || _p_items === void 0 ? void 0 : _p_items.map((a)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: a.demanda
                                                }, a.id, false, {
                                                    fileName: "[project]/components/charts/Nightingale.tsx",
                                                    lineNumber: 50,
                                                    columnNumber: 23
                                                }, void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/components/charts/Nightingale.tsx",
                                            lineNumber: 48,
                                            columnNumber: 19
                                        }, void 0)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/charts/Nightingale.tsx",
                                    lineNumber: 44,
                                    columnNumber: 17
                                }, void 0);
                            }
                        }, void 0, false, {
                            fileName: "[project]/components/charts/Nightingale.tsx",
                            lineNumber: 39,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/charts/Nightingale.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/charts/Nightingale.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/charts/Nightingale.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_c = Nightingale;
var _c;
__turbopack_context__.k.register(_c, "Nightingale");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/charts/BarrasPorResponsavel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// components/charts/BarrasPorResponsavel.tsx
__turbopack_context__.s([
    "default",
    ()=>BarrasPorResponsavel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/component/ResponsiveContainer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$BarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/chart/BarChart.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Bar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/cartesian/Bar.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$XAxis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/cartesian/XAxis.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$YAxis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/cartesian/YAxis.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$CartesianGrid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/cartesian/CartesianGrid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/component/Tooltip.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function BarrasPorResponsavel(param) {
    let { data } = param;
    _s();
    const counts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BarrasPorResponsavel.useMemo[counts]": ()=>{
            const map = new Map();
            for (const a of data){
                const nomes = String(a.responsaveis || "").split(";").map({
                    "BarrasPorResponsavel.useMemo[counts].nomes": (s)=>s.trim()
                }["BarrasPorResponsavel.useMemo[counts].nomes"]).filter(Boolean);
                var _map_get;
                if (!nomes.length) map.set("(sem)", ((_map_get = map.get("(sem)")) !== null && _map_get !== void 0 ? _map_get : 0) + 1);
                var _map_get1;
                for (const n of nomes)map.set(n, ((_map_get1 = map.get(n)) !== null && _map_get1 !== void 0 ? _map_get1 : 0) + 1);
            }
            return Array.from(map.entries()).map({
                "BarrasPorResponsavel.useMemo[counts]": (param)=>{
                    let [name, value] = param;
                    return {
                        name,
                        value
                    };
                }
            }["BarrasPorResponsavel.useMemo[counts]"]);
        }
    }["BarrasPorResponsavel.useMemo[counts]"], [
        data
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "card-glass h-full p-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "section-header mb-2 font-medium",
                children: "Tarefas por Responsável"
            }, void 0, false, {
                fileName: "[project]/components/charts/BarrasPorResponsavel.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResponsiveContainer"], {
                width: "100%",
                height: "88%",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$BarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BarChart"], {
                    data: counts,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$CartesianGrid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CartesianGrid"], {
                            strokeDasharray: "3 3"
                        }, void 0, false, {
                            fileName: "[project]/components/charts/BarrasPorResponsavel.tsx",
                            lineNumber: 32,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$XAxis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["XAxis"], {
                            dataKey: "name",
                            hide: true
                        }, void 0, false, {
                            fileName: "[project]/components/charts/BarrasPorResponsavel.tsx",
                            lineNumber: 33,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$YAxis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["YAxis"], {
                            allowDecimals: false
                        }, void 0, false, {
                            fileName: "[project]/components/charts/BarrasPorResponsavel.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tooltip"], {}, void 0, false, {
                            fileName: "[project]/components/charts/BarrasPorResponsavel.tsx",
                            lineNumber: 35,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Bar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Bar"], {
                            dataKey: "value"
                        }, void 0, false, {
                            fileName: "[project]/components/charts/BarrasPorResponsavel.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/charts/BarrasPorResponsavel.tsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/charts/BarrasPorResponsavel.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/charts/BarrasPorResponsavel.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_s(BarrasPorResponsavel, "VRoO3h9GsQIipVDi31urc2lDN5Y=");
_c = BarrasPorResponsavel;
var _c;
__turbopack_context__.k.register(_c, "BarrasPorResponsavel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/charts/SankeyAreaLocalidade.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// components/charts/SankeyAreaLocalidade.tsx
__turbopack_context__.s([
    "default",
    ()=>SankeyAreaLocalidade
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/component/ResponsiveContainer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$Sankey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/chart/Sankey.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/component/Tooltip.js [app-client] (ecmascript)");
"use client";
;
;
function buildSankeyAreaLocalidade(ativs) {
    const base = ativs.filter((a)=>{
        var _a_status;
        return ((_a_status = a.status) !== null && _a_status !== void 0 ? _a_status : "") !== "Concluído";
    });
    const norm = function(s) {
        let fallback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "Sem valor";
        return (s !== null && s !== void 0 ? s : "").toString().trim() || fallback;
    };
    const areasSet = new Set();
    const locsSet = new Set();
    const pair = new Map();
    for (const a of base){
        const area = norm(a.area_solicitante, "Sem área");
        const loc = norm(a.localidade, "Sem localidade");
        areasSet.add(area);
        locsSet.add(loc);
        const k = "".concat(area, "||").concat(loc);
        var _pair_get;
        const arr = (_pair_get = pair.get(k)) !== null && _pair_get !== void 0 ? _pair_get : [];
        arr.push(a);
        pair.set(k, arr);
    }
    const areas = Array.from(areasSet);
    const locs = Array.from(locsSet);
    const areaKey = (n)=>"A:".concat(n);
    const locKey = (n)=>"L:".concat(n);
    const nodes = [
        ...areas.map((n)=>({
                name: n
            })),
        ...locs.map((n)=>({
                name: n
            }))
    ];
    const idx = new Map();
    nodes.forEach((n, i)=>{
        if (i < areas.length) idx.set(areaKey(n.name), i);
        else idx.set(locKey(n.name), i);
    });
    const links = [];
    for (const [k, items] of pair){
        const [area, loc] = k.split("||");
        const s = idx.get(areaKey(area));
        const t = idx.get(locKey(loc));
        const value = items.length;
        if (s != null && t != null && value > 0) {
            links.push({
                source: s,
                target: t,
                value,
                items
            });
        }
    }
    return {
        nodes,
        links
    };
}
function SankeyAreaLocalidade(param) {
    let { data } = param;
    const sankey = buildSankeyAreaLocalidade(data);
    if (sankey.nodes.length === 0 || sankey.links.length === 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center h-full text-sm text-slate-500",
            children: "Sem dados para exibir"
        }, void 0, false, {
            fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
            lineNumber: 67,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResponsiveContainer"], {
        width: "100%",
        height: "100%",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$Sankey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sankey"], {
            data: sankey,
            nodePadding: 18,
            nodeWidth: 10,
            margin: {
                left: 8,
                right: 8,
                top: 8,
                bottom: 8
            },
            link: {
                stroke: "#cbd5e1",
                strokeOpacity: 0.6
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tooltip"], {
                content: (param)=>{
                    let { active, payload } = param;
                    var _payload_;
                    if (!active || !(payload === null || payload === void 0 ? void 0 : payload.length)) return null;
                    const p = (_payload_ = payload[0]) === null || _payload_ === void 0 ? void 0 : _payload_.payload;
                    if (!p) return null;
                    // --- HOVER EM LINK (tem source/target numéricos) ---
                    const isLink = typeof p.source === "number" && typeof p.target === "number" && Array.isArray(p.items);
                    if (isLink) {
                        var _sankey_nodes_p_source, _sankey_nodes_p_target;
                        var _sankey_nodes_p_source_name;
                        const sourceName = (_sankey_nodes_p_source_name = (_sankey_nodes_p_source = sankey.nodes[p.source]) === null || _sankey_nodes_p_source === void 0 ? void 0 : _sankey_nodes_p_source.name) !== null && _sankey_nodes_p_source_name !== void 0 ? _sankey_nodes_p_source_name : "—";
                        var _sankey_nodes_p_target_name;
                        const targetName = (_sankey_nodes_p_target_name = (_sankey_nodes_p_target = sankey.nodes[p.target]) === null || _sankey_nodes_p_target === void 0 ? void 0 : _sankey_nodes_p_target.name) !== null && _sankey_nodes_p_target_name !== void 0 ? _sankey_nodes_p_target_name : "—";
                        const items = p.items;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "card-glass p-2 text-xs max-w-[320px]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-medium mb-1",
                                    children: [
                                        sourceName,
                                        " → ",
                                        targetName,
                                        ": ",
                                        p.value
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
                                    lineNumber: 101,
                                    columnNumber: 19
                                }, void 0),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "list-disc pl-4 space-y-0.5",
                                    children: items.map((a, i)=>{
                                        var _a_id;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: a.demanda
                                        }, (_a_id = a.id) !== null && _a_id !== void 0 ? _a_id : "".concat(a.demanda, "-").concat(i), false, {
                                            fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
                                            lineNumber: 106,
                                            columnNumber: 23
                                        }, void 0);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
                                    lineNumber: 104,
                                    columnNumber: 19
                                }, void 0)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
                            lineNumber: 100,
                            columnNumber: 17
                        }, void 0);
                    }
                    var _p_name;
                    // --- HOVER EM NÓ (payload.name/value) ---
                    const nodeName = (_p_name = p.name) !== null && _p_name !== void 0 ? _p_name : "—";
                    var _p_value;
                    const nodeValue = (_p_value = p.value) !== null && _p_value !== void 0 ? _p_value : 0;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "card-glass p-2 text-xs",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "font-medium",
                            children: [
                                nodeName,
                                ": ",
                                nodeValue
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
                            lineNumber: 118,
                            columnNumber: 17
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
                        lineNumber: 117,
                        columnNumber: 15
                    }, void 0);
                }
            }, void 0, false, {
                fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
                lineNumber: 82,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
            lineNumber: 75,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/charts/SankeyAreaLocalidade.tsx",
        lineNumber: 74,
        columnNumber: 5
    }, this);
}
_c = SankeyAreaLocalidade;
var _c;
__turbopack_context__.k.register(_c, "SankeyAreaLocalidade");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/charts/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// components/charts/index.ts
__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$Nightingale$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/charts/Nightingale.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$BarrasPorResponsavel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/charts/BarrasPorResponsavel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$SankeyAreaLocalidade$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/charts/SankeyAreaLocalidade.tsx [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/charts/Nightingale.tsx [app-client] (ecmascript) <export default as Nightingale>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Nightingale",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$Nightingale$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$Nightingale$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/charts/Nightingale.tsx [app-client] (ecmascript)");
}),
"[project]/components/charts/BarrasPorResponsavel.tsx [app-client] (ecmascript) <export default as BarrasPorResponsavel>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BarrasPorResponsavel",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$BarrasPorResponsavel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$BarrasPorResponsavel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/charts/BarrasPorResponsavel.tsx [app-client] (ecmascript)");
}),
"[project]/components/charts/SankeyAreaLocalidade.tsx [app-client] (ecmascript) <export default as SankeyAreaLocalidade>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SankeyAreaLocalidade",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$SankeyAreaLocalidade$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$SankeyAreaLocalidade$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/charts/SankeyAreaLocalidade.tsx [app-client] (ecmascript)");
}),
"[project]/app/(app)/dashboard/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/(app)/dashboard/page.tsx
__turbopack_context__.s([
    "default",
    ()=>DashboardPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAtividadesAll$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useAtividadesAll.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$charts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/charts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$badges$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/charts/badges.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/charts/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$Nightingale$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Nightingale$3e$__ = __turbopack_context__.i("[project]/components/charts/Nightingale.tsx [app-client] (ecmascript) <export default as Nightingale>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$BarrasPorResponsavel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarrasPorResponsavel$3e$__ = __turbopack_context__.i("[project]/components/charts/BarrasPorResponsavel.tsx [app-client] (ecmascript) <export default as BarrasPorResponsavel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$SankeyAreaLocalidade$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SankeyAreaLocalidade$3e$__ = __turbopack_context__.i("[project]/components/charts/SankeyAreaLocalidade.tsx [app-client] (ecmascript) <export default as SankeyAreaLocalidade>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function DashboardPage() {
    _s();
    const { data: atividades = [] } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAtividadesAll$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtividadesAll"])();
    const urgData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "DashboardPage.useMemo[urgData]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$charts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radialDataFromGroup"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$charts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupByKey"])(atividades, "urgencia"))
    }["DashboardPage.useMemo[urgData]"], [
        atividades
    ]);
    const impData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "DashboardPage.useMemo[impData]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$charts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radialDataFromGroup"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$charts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupByKey"])(atividades, "importancia"))
    }["DashboardPage.useMemo[impData]"], [
        atividades
    ]);
    const quadData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "DashboardPage.useMemo[quadData]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$charts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radialDataFromGroup"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$charts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupByKey"])(atividades, "quadrante"))
    }["DashboardPage.useMemo[quadData]"], [
        atividades
    ]);
    const abertas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "DashboardPage.useMemo[abertas]": ()=>atividades.filter({
                "DashboardPage.useMemo[abertas]": (a)=>a.status !== "Concluído"
            }["DashboardPage.useMemo[abertas]"])
    }["DashboardPage.useMemo[abertas]"], [
        atividades
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-[15px] pt-[15px]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-3",
                style: {
                    height: "40vh"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-5 gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-3 grid grid-cols-3 gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$Nightingale$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Nightingale$3e$__["Nightingale"], {
                                    title: "Urgência",
                                    data: urgData
                                }, void 0, false, {
                                    fileName: "[project]/app/(app)/dashboard/page.tsx",
                                    lineNumber: 39,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$Nightingale$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Nightingale$3e$__["Nightingale"], {
                                    title: "Importância",
                                    data: impData
                                }, void 0, false, {
                                    fileName: "[project]/app/(app)/dashboard/page.tsx",
                                    lineNumber: 40,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$Nightingale$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Nightingale$3e$__["Nightingale"], {
                                    title: "Quadrante",
                                    data: quadData
                                }, void 0, false, {
                                    fileName: "[project]/app/(app)/dashboard/page.tsx",
                                    lineNumber: 41,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(app)/dashboard/page.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$BarrasPorResponsavel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarrasPorResponsavel$3e$__["BarrasPorResponsavel"], {
                                data: atividades
                            }, void 0, false, {
                                fileName: "[project]/app/(app)/dashboard/page.tsx",
                                lineNumber: 45,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(app)/dashboard/page.tsx",
                            lineNumber: 44,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(app)/dashboard/page.tsx",
                    lineNumber: 36,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(app)/dashboard/page.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-5 gap-3",
                style: {
                    height: "calc(60vh - 15px)",
                    marginBottom: 15
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-span-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$SankeyAreaLocalidade$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SankeyAreaLocalidade$3e$__["SankeyAreaLocalidade"], {
                            data: atividades
                        }, void 0, false, {
                            fileName: "[project]/app/(app)/dashboard/page.tsx",
                            lineNumber: 57,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(app)/dashboard/page.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-span-3 card-glass p-3 flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "section-header mb-2 font-medium",
                                children: "Atividades abertas"
                            }, void 0, false, {
                                fileName: "[project]/app/(app)/dashboard/page.tsx",
                                lineNumber: 62,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "overflow-auto rounded-lg border bg-white/60",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                    className: "w-full text-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            className: "bg-gray-100",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "[&>th]:px-3 [&>th]:py-2 text-left",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        children: "Demanda"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                        lineNumber: 67,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        children: "Prazo"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                        lineNumber: 68,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        children: "Urgência"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                        lineNumber: 69,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        children: "Importância"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                        lineNumber: 70,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        children: "Quadrante"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                        lineNumber: 71,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                lineNumber: 66,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(app)/dashboard/page.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            className: "[&>tr]:border-t",
                                            children: [
                                                abertas.map((a)=>{
                                                    var _a_urgencia, _a_importancia, _a_quadrante;
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                        className: "[&>td]:px-3 [&>td]:py-2 align-top",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "max-w-[560px]",
                                                                children: a.demanda
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                                lineNumber: 77,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                children: a.prazo ? new Date(a.prazo).toLocaleDateString() : "-"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                                lineNumber: 78,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$badges$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["levelBadge"])((_a_urgencia = a.urgencia) !== null && _a_urgencia !== void 0 ? _a_urgencia : undefined)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                                lineNumber: 79,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$badges$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["levelBadge"])((_a_importancia = a.importancia) !== null && _a_importancia !== void 0 ? _a_importancia : undefined)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                                lineNumber: 80,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$charts$2f$badges$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["quadranteBadge"])((_a_quadrante = a.quadrante) !== null && _a_quadrante !== void 0 ? _a_quadrante : undefined)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                                lineNumber: 81,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, a.id, true, {
                                                        fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                        lineNumber: 76,
                                                        columnNumber: 19
                                                    }, this);
                                                }),
                                                !abertas.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        colSpan: 5,
                                                        className: "px-3 py-4 text-gray-500",
                                                        children: "Sem itens em aberto."
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                        lineNumber: 86,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(app)/dashboard/page.tsx",
                                                    lineNumber: 85,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(app)/dashboard/page.tsx",
                                            lineNumber: 74,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(app)/dashboard/page.tsx",
                                    lineNumber: 64,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(app)/dashboard/page.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(app)/dashboard/page.tsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(app)/dashboard/page.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(app)/dashboard/page.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_s(DashboardPage, "6FitzvgzcTxMTACG3ejj7BjM6eI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAtividadesAll$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtividadesAll"]
    ];
});
_c = DashboardPage;
var _c;
__turbopack_context__.k.register(_c, "DashboardPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_0d162dab._.js.map