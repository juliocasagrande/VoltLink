(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_307f9496._.js",
  "static/chunks/node_modules_a17d905b._.js"
],
    source: "dynamic"
});
